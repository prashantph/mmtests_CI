#!/bin/sh

autoheader || exit 1
autoconf || exit 1

exit 0

